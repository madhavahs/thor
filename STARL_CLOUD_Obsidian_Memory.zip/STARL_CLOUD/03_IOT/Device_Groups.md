# Device Groups

> STARL_CLOUD project memory file.

## Purpose
Document the requirements, design, implementation, testing, or decisions related to **Device Groups**.

## Notes

## References

